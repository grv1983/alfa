package ua.alfabank.work64;

import java.util.Scanner;

public class Task64 {
    public static String convertDecimalToBinary(int  number){
        String str = "";
        while (number > 0) {
            if (number % 2 == 0) {
                str = "0" + str;
            } else {
                str = "1" + str;
            }
            number /= 2;
        }

        return str;
    }

    public static void main(String[] args) {
        int number;
        Scanner sc = new Scanner(System.in);
        System.out.print("Введите целое число-->> ");
        number = sc.nextInt();

        if ( number < 0 ){
            System.out.println("Число " + number +" отрицательное");
        }else{
            System.out.println( convertDecimalToBinary(number));
        }
    }
}
