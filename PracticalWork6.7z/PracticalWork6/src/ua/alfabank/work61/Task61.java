package ua.alfabank.work61;

import java.util.Scanner;

public class Task61 {

    public static void main(String[] args) {
        double s ;
        Scanner sc = new Scanner ( System.in ) ;
        System.out.println( "Введите значение трех сторон треугольника :" );
        System.out.print( "Введите размер первой стороны треугольника -->> " );
        double a = sc.nextDouble() ;
        System.out.print( "Введите размер второй стороны треугольника -->> " );
        double b = sc.nextDouble() ;
        System.out.print( "Введите размер третей стороны треугольника -->> " );
        double c = sc.nextDouble() ;

        s = areaTringle( a , b , c ) ;
        String str = String.format("%.2f", s );
        System.out.println( "Площадь треугольника -->> " + str );
        //System.out.println( "Площадь треугольника -->> " + s );

    }
    public static double areaTringle ( double a, double b , double c ){
        double result , p , s;
        p = ( a + b + c ) / 2 ;
        System.out.println( "Периметрнашего нашего треугольни -->> " + p  );
        s = Math.sqrt( p * ( p - a ) * ( p - b ) * ( p - c ) ) ;
        return result = s ;
    }

}
