package ua.alfabank.work62;

import java.util.Scanner;

public class Task62 {
    public  static String latestDigit(int number){
        number = number % 100 ;
        String str;
        str = String.valueOf(number % 10);
        str = str + number / 10 ;
        return str;
    }

    public static void main(String[] args) {
        int num;
        Scanner sc = new Scanner(System.in);
        System.out.print("введите целочмсленное значение -->>");
        num = sc.nextInt();
        String str = latestDigit(num);
        System.out.print("Преобразованое число -->>" + str);

    }
}
