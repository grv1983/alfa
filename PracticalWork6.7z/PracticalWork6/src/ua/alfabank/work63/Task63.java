package ua.alfabank.work63;

import java.util.Scanner;

public class Task63 {
    public static char getFirstCharacterOfWord(String str, int numberWord){
        char ch = 1 ;
        int i = 1;
        int pos = 1;
        String posStr;
        String str1 =  str;
        while (i <= numberWord && str.indexOf(' ') != -1){
            if (i == numberWord ){
                return str.charAt(0) ;
            }
            str = str.substring( str.indexOf(" ")+1);
             i++;
        }

        return '-';
    }

    public static void main(String[] args) {
        String str;
        int numberWord;
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите строку: ");
        //первое второе третье четвертое пятое шестое
        str = sc.nextLine();
        System.out.println("Введите номер слова: ");
        numberWord = sc.nextInt();
        System.out.println("выводим первый символ -->> " + getFirstCharacterOfWord(str , numberWord) );

    }
}
