package work31;

import java.util.Scanner;

public class Task31 {
    public static void main(String[] args) {
        double funts , funt = 0.4536 ;
        System.out.print("Введите фунты -> ");
        Scanner line = new Scanner(System.in);
        funts = line.nextDouble();
        double massa = funts * funt ;
        int kilo = (int)  massa  ;
        double gramm = ( massa - kilo ) * 1000 ;
        System.out.println("В " + funts + " функах "+ kilo + " килограмм и " + gramm + " грамм");
    }
}
