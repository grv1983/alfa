package work33;

public class Task33 {
    public static void main(String[] args) {
        double staffUSD = 830 ;//, rate = 28.5 ;
        staffUSD = staffUSD * 0.87 + staffUSD * 0.07;
        System.out.println("Окончательная стоимость итальянского шкафа на распродаже после уценки");
        System.out.println("на 13% и увеличения курса доллара на 7% составила " + staffUSD + " $");

    }
}
