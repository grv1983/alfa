package work32;

import java.util.Scanner;

public class Task32 {
    public static void main(String[] args) {
        double deposite,income;
        int month, procent = 12 ;
        Scanner line = new Scanner(System.in);
        System.out.print("Введите сумму депозита -> ");
        deposite = line.nextDouble();
        System.out.print("Введите на сколько месяцев вклад -> ");
        month = line.nextInt();
        System.out.print("Сумма вклада с процентами = " + (deposite + deposite * procent/100 / 12 * month) + " грн.");
    }
}
