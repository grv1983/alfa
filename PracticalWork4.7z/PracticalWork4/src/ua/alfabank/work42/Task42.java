package ua.alfabank.work42;

import java.util.Scanner;

public class Task42 {
    public static void main(String[] args) {
        int num ;
        String numText ;
        Scanner line = new Scanner(System.in);
        System.out.print("Введите число целого типа от 1 до 9 -> ");
        num = line.nextInt();
        switch (num){
            case 1 : numText = "Один->" +num; break;
            case 2 : numText = "Два->" +num; break;
            case 3 : numText = "Три->" +num; break;
            case 4 : numText = "Четыре->" +num; break;
            case 5 : numText = "Пять->" +num; break;
            case 6 : numText = "Шесть->" +num; break;
            case 7 : numText = "Семь->" +num; break;
            case 8 : numText = "Восемь->" +num; break;
            case 9 : numText = "Девять->" +num; break;
            default: numText = "Число " + num + " не в диапазоне от 1 до 9!";
        }
        System.out.println(numText);
    }
}
