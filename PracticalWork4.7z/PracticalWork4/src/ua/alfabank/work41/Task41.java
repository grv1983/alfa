package ua.alfabank.work41;

import java.util.Scanner;

public class Task41 {
    public static void main(String[] args) {
        double num1 , num2 , num3 , maxNum ;
        String numText = "Наибольшее число из трех - первое, имеет значение: ";
        Scanner  line = new Scanner(System.in);
        System.out.println("Введите три числа для сравнения");
        System.out.print("Первое число : ");
        num1 = line.nextDouble();
        maxNum = num1;
        System.out.print("Второе число : ");
        num2 = line.nextDouble();
        System.out.print("Третье число : ");
        num3 = line.nextDouble();
        if (num1 < num2) {
            maxNum = num2 ;
            numText = "Наибольшее число из трех - второе, имеет значение: ";
        }
        if (num2 < num3) {
            maxNum = num3 ;
            numText = "Наибольшее число из трех - третье, имеет значение: ";
        }
        System.out.println(numText+maxNum);
    }
}
