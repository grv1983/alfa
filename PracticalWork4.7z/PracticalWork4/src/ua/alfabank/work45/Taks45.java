package ua.alfabank.work45;

public class Taks45 {
    public static void main(String[] args) {
        int i = 1 , j =1 ;
        System.out.println(" * |  1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 ");
        System.out.println("---------------------------------------");
        while (i < 10){
            System.out.print(" " + i + " | ");
            while (j < 10){
                if ((i*j)<10) {
                    System.out.print(" " + i * j + "  ");
                }
                else {
                    System.out.print(" " + i * j + " ");
                }
                j++ ;
            }
                i++ ;
                j = 1 ;
            System.out.println("");
        }
    }
}
