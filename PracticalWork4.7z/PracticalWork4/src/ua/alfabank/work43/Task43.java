package ua.alfabank.work43;

public class Task43 {
    public static void main(String[] args) {
        int i = 1, j = 1;
        String result;
        while (i<= 8) {

            while (j>0) {
                System.out.print(j + " ");
                j--;
            }
            i++;
            j = i ;
            System.out.println();
        }
    }
}
