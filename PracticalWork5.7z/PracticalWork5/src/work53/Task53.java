package work53;

public class Task53 {
    public static void main(String[] args) {
        final char simbol = (char) 34 ;
        String str = "An information system is designed to collect, process, store and distribute information" ;
        String firstWorld, lastWorld ;
        firstWorld = str.substring( 0 , str.indexOf(" ")) ;
        lastWorld = str.substring( str.lastIndexOf(" ") + 1 , str.length() ) ;
       // str = str.replaceAll( str.substring( 0 , str.indexOf(" ") ) , lastWorld) ;
        str = str.substring( str.indexOf(" ") + 1 , str.length() ) ;
        str = str.substring( 0 , str.lastIndexOf( " " ) ) ;
        System.out.println("*" + lastWorld + " " + str + " **" + firstWorld);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("====Примечание====");
        System.out.println("*  - слово " +  simbol +lastWorld + simbol + " было последним в исходном тексте");
        System.out.println("** - слово " + simbol + firstWorld + simbol + " было первым в исходном тексте");
    }
}
