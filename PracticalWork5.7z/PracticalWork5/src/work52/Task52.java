package work52;

public class Task52 {
    public static void main(String[] args) {
        String str = "Национальный Авиационный Уневерститет"  ;
        final char simbol = (char) 34 ;
        char firstChar , secondChar , thirdChar ;
        firstChar = str.charAt(0);
        secondChar =  str.charAt( str.indexOf(" ") + 1 );
        thirdChar = str.charAt( str.lastIndexOf( " " ) + 1 ) ;
        System.out.println("Абривиатура названия университета " + simbol + str + simbol + " -> "+ firstChar + secondChar + thirdChar );

    }
}
