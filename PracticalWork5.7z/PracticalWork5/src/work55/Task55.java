package work55;

import java.util.Scanner;

public class Task55 {
    public static void main(String[] args) {
        String str ;
        Scanner sc = new Scanner(System.in) ;
        str = sc.nextLine() ;

        System.out.println(st .3 6+9,g/8*59hj 127gf0 t2\t\