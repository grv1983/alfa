package work54;

import java.util.Locale;

public class Task54 {
    public static void main(String[] args) {
        String myStr1 = "Cartoon" , myStr2 = "Tomcat" ;
        myStr1 = myStr1.toLowerCase(Locale.ROOT) ;
        myStr2 = myStr2.toLowerCase(Locale.ROOT) ;
        int i = 0 ;
        while ( i < myStr1.length() ) {
            char symbol = myStr1.charAt( i ) ;
            if ( myStr2.indexOf( symbol ) == -1 ){
                System.out.print( symbol + " " );
            }

            i++ ;
        }
    }
}
